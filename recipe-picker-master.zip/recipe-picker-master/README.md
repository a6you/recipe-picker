simple algorithm that returns the do-able recipes from a list of ingredients, two test cases implemented (not thorough validation)
